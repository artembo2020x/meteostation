-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Мар 10 2017 г., 13:11
-- Версия сервера: 5.7.17-11-beget-log
-- Версия PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `gribovkc_db`
--

-- --------------------------------------------------------

--
-- Структура таблицы `meteostation`
--
-- Создание: Мар 10 2017 г., 05:24
-- Последнее обновление: Мар 10 2017 г., 09:31
--

DROP TABLE IF EXISTS `meteostation`;
CREATE TABLE `meteostation` (
  `name` varchar(128) DEFAULT NULL,
  `type` varchar(128) DEFAULT NULL,
  `meteoId` int(11) NOT NULL,
  `meteoDriver` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `meteostation`
--

INSERT INTO `meteostation` (`name`, `type`, `meteoId`, `meteoDriver`) VALUES
('FakeStation', 'обычная', 1241, 'fake'),
('London station', 'ordinary', 2172798, 'openWeatherMap'),
('Тестовая станция', 'обычный', 2172799, 'openWeatherMap');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `meteostation`
--
ALTER TABLE `meteostation`
  ADD PRIMARY KEY (`meteoId`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
